use std::{cell::Cell, hint::black_box, time::{Duration, Instant}};
use tenferro_cpu::CpuBackend;
use tenferro_tensor::{BackendSessionHost, Tensor, TensorRead, TensorView, TypedTensorView};
use crate::{ConcreteEinsumPlan, TensorReadEinsumExt};

thread_local! { pub(super) static BYPASS: Cell<bool> = const { Cell::new(false) }; }

fn sample(mut f: impl FnMut()) -> f64 {
    for _ in 0..20 { f(); }
    let start = Instant::now();
    let mut n = 0;
    while start.elapsed() < Duration::from_millis(200) {
        f(); n += 1;
    }
    start.elapsed().as_secs_f64() * 1e6 / n as f64
}

#[test]
#[ignore]
fn compare_same_process() {
    println!("PROBE,threads,layout,phase,pair,bypass,us");
    for threads in [0, 1] {
        let mut backend = if threads == 0 { CpuBackend::new() } else { CpuBackend::with_threads(threads).unwrap() };
        eprintln!("THREADS requested={threads} actual={} info={:?}", backend.num_threads(), backend.execution_info());
        let n = 256;
        let adata: Vec<f64> = (0..n*n).map(|i| ((i*7+1)%19) as f64/19.-0.5).collect();
        let b = Tensor::from_vec_col_major([n,n], (0..n*n).map(|i| ((i*7+3)%19) as f64/19.-0.5).collect::<Vec<_>>()).unwrap();
        for (layout, strides, offset) in [("compact", [1,n as isize],0), ("transpose",[n as isize,1],0), ("reverse",[-1,n as isize],n as isize-1)] {
            let a = TypedTensorView::from_slice([n,n],strides,offset,&adata).unwrap();
            let inputs = [TensorRead::from_tensor(&b), TensorRead::from_view(TensorView::F64(a))];
            let plans: Vec<_> = [false,true].into_iter().map(|bypass| {
                BYPASS.with(|b| b.set(bypass));
                ConcreteEinsumPlan::prepare_read(&inputs,"jk,ij->ik").unwrap()
            }).collect();
            let expected: Vec<f64> = (0..n*n).map(|p| (0..n).map(|k| {
                let index=offset+(p%n) as isize*strides[0]+k as isize*strides[1];
                adata[index as usize]*b.as_slice::<f64>().unwrap()[k+n*(p/n)]
            }).sum()).collect();
            for plan in &plans {
                let out=backend.with_backend_session(|s| plan.execute_read(&inputs,s)).unwrap();
                for (a,b) in out.as_slice::<f64>().unwrap().iter().zip(&expected) { assert!((a-b).abs()<1e-9); }
            }
            for phase in ["ordinary","fresh_plan","prepared"] {
                for pair in 0..9 {
                    let order=if pair%2==0 { [false,true] } else { [true,false] };
                    for bypass in order {
                        BYPASS.with(|b| b.set(bypass));
                        crate::eager::probe_totals();
                        let us=match phase {
                            "prepare" => sample(|| { black_box(ConcreteEinsumPlan::prepare_read(black_box(&inputs),black_box("jk,ij->ik")).unwrap()); }),
                            "ordinary" => sample(|| {
                                let out=backend.with_backend_session(|s| {
                                    BYPASS.with(|b| b.set(bypass));
                                    inputs.einsum_read(black_box("jk,ij->ik"),s)
                                }).unwrap();
                                black_box(out.as_slice::<f64>().unwrap());
                            }),
                            "fresh_plan" => sample(|| {
                                let out=backend.with_backend_session(|s| {
                                    BYPASS.with(|b| b.set(bypass));
                                    let plan=ConcreteEinsumPlan::prepare_read(black_box(&inputs),black_box("jk,ij->ik")).unwrap();
                                    plan.execute_read(&inputs,s)
                                }).unwrap();
                                black_box(out.as_slice::<f64>().unwrap());
                            }),
                            _ => sample(|| {
                                let out=backend.with_backend_session(|s| plans[bypass as usize].execute_read(black_box(&inputs),s)).unwrap();
                                black_box(out.as_slice::<f64>().unwrap());
                            }),
                        };
                        let (dot,fast,calls)=crate::eager::probe_totals();
                        println!("STAGES,{threads},{layout},{phase},{pair},{bypass},{dot},{fast},{calls}");
                        println!("PROBE,{threads},{layout},{phase},{pair},{bypass},{us:.6}");
                    }
                }
            }
        }
    }
}
