# Maintainer-authorized recheck of #1772 regression

The user explicitly authorized a new recheck and root-cause investigation after
the initial stop; this is not a silent third retry. No merge or Phase 2 work.

Question: do default-thread reversed-operand compact/transposed 256 read calls
really cost more after the binary bypass, and if so why?

Revisions: base d65a422c, candidate 3b0e4831 (production code 166ab813).
The existing binary_planning.rs at d65a422c is identical at both revisions.
First build each into its own fresh target directory (no copied fingerprints or
shared build target), in release/default cpu-faer on this Linux host. Record
commands, source revisions, compiler, hashes, environment and execution output.

Run seven matched process pairs of the existing complete 36-case example, both
default and explicit one-thread settings, alternating AB/BA. Same 5 x >=50 ms
samples, no affinity changes. Retain all results. Analyze process medians and
paired log ratios with t(6)=2.447 as before. Primary recheck is each of the two
previously flagged default-thread cases separately: CI lower > 1 demonstrates a
repeatable slowdown, CI covering 1 is inconclusive, and upper < 1.10 excludes
the previously claimed >=10% regression at the stated confidence level. Do not
convert a wide interval into no-regression. Report all controls, not just these.

If absent or noisy, include an A/A negative control with the same executable
before blaming source changes. If reproducible, use same-process diagnostics
for search/fixed pair planning and execution, with identical input/backend and
alternating order, to distinguish code-path effects from binary/process/host
effects. Such diagnostics do not replace the ordinary public API measurement.
No binary optimizer will be added unless the root cause warrants it.

perf is unavailable (perf_event_paranoid=4); do not change shared kernel settings.
Use existing diagnostics, /usr/bin/time and bounded source instrumentation if
necessary. No dedicated harness framework or resource-admission system.
