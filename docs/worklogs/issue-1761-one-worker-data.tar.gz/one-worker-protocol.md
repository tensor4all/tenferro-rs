# One-worker-only follow-up, authorized by the user's latest instruction

No further 64/4/8-worker measurements. The completed unpinned one-worker matched
comparison already excludes the previously reported >=10% large reversed-input
regression, but prepared/2, /8 and /32 remain noisy across processes.

One complete matched comparison using the unchanged independent-build executables
and unchanged 36-case example, explicit 1 worker, with native `taskset -c 32`.
CPU 32 is the worker selected by the existing one-thread backend with allowed
CPUs 0-63 (confirmed in prior execution_info); this pins the initiating thread
as well instead of leaving it free to migrate. It also restricts the process's
allowed set to CPU 32, so this is a separately reported pinned one-worker
configuration, not a replacement claim about default/unpinned execution.
No shared settings or unrelated processes are modified; no affinity framework.

Seven matched AB/BA process pairs, existing 5 x >=50ms samples per case. Analyze
as before: per-process median; paired log-ratio Student-t CI with df6, critical
2.447. Primary ordinary-string 2/8/32 aggregate upper CI <1; every individual
control upper CI <1.10. Retain every case and sample. One complete comparison,
not repeated until success. If still noisy, report the remaining uncertainty.
No source optimization is warranted solely to make a noisy comparison pass.
