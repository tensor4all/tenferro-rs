import csv, math, statistics as s
from pathlib import Path
runs = []
for path in sorted(Path(__file__).parent.glob('run-*.csv')):
    groups = {}
    for row in csv.DictReader(path.open()):
        groups.setdefault(row['case'], []).append(float(row['ns_per_call']) / 1000)
    assert len(groups) == 6 and all(len(v) == 5 for v in groups.values())
    runs.append({k: s.median(v) for k, v in groups.items()})
assert len(runs) == 7
print('case | median us | range us | CV | ratio/shared 95% CI')
for case in runs[0]:
    values = [r[case] for r in runs]
    logs = [math.log(r[case]/r['shared']) for r in runs]
    mean = s.mean(logs)
    half = 2.447 * s.stdev(logs) / math.sqrt(7)
    print(f'{case} | {s.median(values):.3f} | {min(values):.3f}–{max(values):.3f} | {s.stdev(values)/s.mean(values):.1%} | {math.exp(mean):.3f} [{math.exp(mean-half):.3f}, {math.exp(mean+half):.3f}]')
    if case in ('shared', 'per_op', 'eager', 'active_forward'):
        assert s.stdev(values)/s.mean(values) <= 0.10, 'INCONCLUSIVE: chain CV > 10%'
