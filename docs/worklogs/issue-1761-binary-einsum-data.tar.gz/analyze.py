import csv, math, statistics as s, sys
from pathlib import Path
root = Path(sys.argv[1])

def interval(values):
    mean = s.mean(values)
    half = 2.447 * s.stdev(values) / math.sqrt(7)
    return tuple(math.exp(x) for x in (mean, mean-half, mean+half))

for threads in ('default', '1'):
    medians = {}
    for pair in range(1, 8):
        for rev in ('base', 'candidate'):
            rows = list(csv.DictReader((root / f'{threads}-{pair}-{rev}.csv').open()))
            names = list(dict.fromkeys(r['case'] for r in rows))
            assert len(names) == 36 and len(rows) == 180
            for name in names:
                samples = [float(r['ns_per_call']) for r in rows if r['case'] == name]
                assert len(samples) == 5
                medians[pair, rev, name] = s.median(samples)
    logs = {name: [math.log(medians[p, 'candidate', name]/medians[p, 'base', name]) for p in range(1, 8)] for name in names}
    primary = [s.mean(logs[f'ordinary_string/{n}'][p] for n in (2,8,32)) for p in range(7)]
    print(f'\n## Threads: {threads}\nPrimary ratio, 95% CI: {interval(primary)}\n')
    print('| Case | Base us | Candidate us | Ratio [95% CI] | Max process CoV | Non-regression |')
    print('|---|---:|---:|---|---:|---|')
    for name in names:
        base = [medians[p, 'base', name] for p in range(1,8)]
        cand = [medians[p, 'candidate', name] for p in range(1,8)]
        ratio, lo, hi = interval(logs[name])
        cov = max(s.stdev(x)/s.mean(x) for x in (base, cand))
        status = 'PASS' if hi < 1.10 else ('REGRESSION' if lo >= 1.10 else 'INCONCLUSIVE')
        print(f'| {name} | {s.median(base)/1000:.3f} | {s.median(cand)/1000:.3f} | {ratio:.4f} [{lo:.4f}, {hi:.4f}] | {cov:.1%} | {status} |')
